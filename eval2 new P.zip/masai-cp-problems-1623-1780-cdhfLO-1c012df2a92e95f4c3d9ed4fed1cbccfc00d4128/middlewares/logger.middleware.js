const logger = () => {};

module.exports = {
  logger,
};

//+0.5
